from django.apps import AppConfig


class ReservoirPredictionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'reservoir_prediction'
