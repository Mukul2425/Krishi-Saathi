document.addEventListener('DOMContentLoaded', function () {
    const toggleCheckbox = document.getElementById('toggle-language');
    let isEnglish = !toggleCheckbox.checked; // Default state based on checkbox

    // Set initial language display
    updateLanguage();

    toggleCheckbox.addEventListener('change', function () {
        isEnglish = !toggleCheckbox.checked;
        updateLanguage();
    });

    function updateLanguage() {
        document.querySelectorAll('.lang-en').forEach(element => {
            element.style.display = isEnglish ? 'block' : 'none';
        });
        document.querySelectorAll('.lang-hi').forEach(element => {
            element.style.display = isEnglish ? 'none' : 'block';
        });
    }
});
